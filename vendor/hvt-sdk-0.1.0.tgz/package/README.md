# `@hvt/sdk`

Zero-dependency JavaScript/TypeScript SDK for HVT.

## What It Covers

- Control-plane auth: login, logout, me, refresh, register
- Runtime auth: runtime login, runtime social providers/login
- Organizations: current org, projects, invitations, permissions
- Users: list, detail, update, delete, role update
- API keys: create, list, revoke
- Webhooks: create, list, update, delete, deliveries
- Audit logs: list and detail

## Usage

```ts
import { HVTClient, API_KEY_CANONICAL_SCOPES } from "@hvt/sdk";

const client = new HVTClient({
  baseUrl: "https://auth.example.com",
  credentials: "include"
});

await client.auth.login({
  email: "owner@example.com",
  password: "secret"
});

const me = await client.auth.me();
const projects = await client.organizations.listProjects();

const runtimeClient = client.withApiKey("hvt_test_...");
const runtimeProviders = await runtimeClient.auth.listRuntimeSocialProviders();
```

## Launch Notes

- The launch model is single-organization per user.
- New API keys should use canonical scopes only:
  - `organization:read`
  - `users:read`
  - `api_keys:read`
  - `webhooks:read`
  - `audit_logs:read`
  - `auth:runtime`
- Webhooks and API-key audit access are project-scoped.
- Runtime auth flows require an API key with `auth:runtime`.

## Packaging

This package ships prebuilt `dist/` files so it can be packed without an additional build tool.
